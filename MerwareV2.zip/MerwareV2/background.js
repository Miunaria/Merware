// Googleスプレッドシートからライセンス情報を確認する関数
async function checkLicense(username, licenseKey) {
    const sheetId = "1zj2Yqj9kgfyv_uaipGYfFT3133xgLru8zS9f7g5sDfc"; // GoogleスプレッドシートID
    const apiKey = "AIzaSyAfLu8Yg5ViXqqIeZt3kasGqql3Z_x_edc";  // Google APIキー
    const sheetUrl = `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/Sheet1?key=${apiKey}`;

    try {
        console.log(`Fetching data from: ${sheetUrl}`); // デバッグ用ログ
        const response = await fetch(sheetUrl);
        
        if (!response.ok) {
            const errorDetails = await response.json();
            console.error("APIリクエストエラー:", errorDetails);
            throw new Error(`Failed to fetch: ${response.status} - ${response.statusText}`);
        }

        const data = await response.json();
        console.log("取得データ:", data); // デバッグ用: APIレスポンスを出力

        const rows = data.values.slice(3); // 4行目以降のデータを取得

        // ユーザー名とライセンスコードを照合
        return rows.some((row) => {
            const [rowUsername, rowLicenseKey] = row;
            return rowUsername === username && rowLicenseKey === licenseKey;
        });
    } catch (error) {
        console.error("ライセンス確認エラー:", error.message);
        return false;
    }
}


// メッセージリスナーを設定
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "verifyLicense") {
        const { username, licenseKey } = message;

        checkLicense(username, licenseKey).then((isValid) => {
            if (isValid) {
                chrome.storage.local.set({ username, licenseKey, licenseStatus: "valid" });
                sendResponse({ success: true });

                // バッジをクリア
                chrome.action.setBadgeText({ text: "" });
            } else {
                chrome.storage.local.set({ licenseStatus: "invalid" });
                sendResponse({ success: false });

                // 機能を無効化 (バッジ表示を変更)
                chrome.action.setBadgeText({ text: "OFF" });
                chrome.action.setBadgeBackgroundColor({ color: "#FF0000" });
            }
        });

        return true; // 非同期応答を使用
    }
});

// ブラウザ起動時の認証処理
chrome.runtime.onStartup.addListener(() => {
    chrome.storage.local.get(["username", "licenseKey"], (data) => {
        const { username, licenseKey } = data;

        if (username && licenseKey) {
            checkLicense(username, licenseKey).then((isValid) => {
                if (isValid) {
                    chrome.storage.local.set({ licenseStatus: "valid" });
                    console.log("ライセンスが有効です");
                    chrome.action.setBadgeText({ text: "" }); // バッジをクリア
                } else {
                    chrome.storage.local.set({ licenseStatus: "invalid" });
                    console.warn("ライセンスが無効です");
                    chrome.action.setBadgeText({ text: "OFF" });
                    chrome.action.setBadgeBackgroundColor({ color: "#FF0000" });
                }
            }).catch((error) => {
                console.error("認証中にエラーが発生しました:", error.message);
                chrome.storage.local.set({ licenseStatus: "invalid" });
                chrome.action.setBadgeText({ text: "OFF" });
                chrome.action.setBadgeBackgroundColor({ color: "#FF0000" });
            });
        } else {
            console.warn("認証情報が見つかりません");
            chrome.storage.local.set({ licenseStatus: "invalid" });
            chrome.action.setBadgeText({ text: "OFF" });
            chrome.action.setBadgeBackgroundColor({ color: "#FF0000" });
        }
    });
});




// ブラウザ起動時にライセンス状態を確認
chrome.runtime.onStartup.addListener(() => {
    chrome.storage.local.get(["licenseStatus"], (data) => {
        if (data.licenseStatus === "invalid") {
            chrome.action.setBadgeText({ text: "OFF" });
            chrome.action.setBadgeBackgroundColor({ color: "#FF0000" });
        } else {
            chrome.action.setBadgeText({ text: "" });
        }
    });
});




chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "downloadCSV") {
        const { url, filename } = message;

        chrome.downloads.download({ url, filename, saveAs: true }, (downloadId) => {
            if (chrome.runtime.lastError) {
                console.error("ダウンロードエラー:", chrome.runtime.lastError.message);
                sendResponse({ success: false, error: chrome.runtime.lastError.message });
            } else {
                console.log("CSVダウンロード成功:", downloadId);
                sendResponse({ success: true });
            }
        });

        return true; // 非同期応答を使用するため
    }
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === "complete" && tab.url.includes("shops")) {
        chrome.tabs.remove(tabId); // タブを閉じる
    }
});

// 拡張機能ボタンが押されたときに data_manager.html を開く
chrome.action.onClicked.addListener(() => {
    chrome.tabs.create({ url: chrome.runtime.getURL("data_manager.html") });
});
