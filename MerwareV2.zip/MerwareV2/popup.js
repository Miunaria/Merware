document.addEventListener("DOMContentLoaded", () => {
  loadBlacklist();

  // データ管理画面を開くボタンの処理
  document.getElementById("openDataManager").addEventListener("click", () => {
    chrome.tabs.create({ url: chrome.runtime.getURL("data_manager.html") });
  });
});

function loadBlacklist() {
  chrome.storage.local.get(["blacklist"], (data) => {
      const blacklist = data.blacklist || [];
      const listElement = document.getElementById("blacklist");
      listElement.innerHTML = "";

      blacklist.forEach((user) => {
          const li = document.createElement("li");
          li.textContent = user;

          const deleteButton = document.createElement("button");
          deleteButton.textContent = "削除";
          deleteButton.addEventListener("click", () => {
              removeFromBlacklist(user);
          });
          li.appendChild(deleteButton);
          listElement.appendChild(li);
      });
  });
}

function removeFromBlacklist(user) {
  chrome.storage.local.get(["blacklist"], (data) => {
      const blacklist = data.blacklist || [];
      const updatedList = blacklist.filter((u) => u !== user);

      chrome.storage.local.set({ blacklist: updatedList }, () => {
          loadBlacklist();
      });
  });
}

document.addEventListener("DOMContentLoaded", () => {
  console.log("DOMContentLoadedイベントが発火しました"); // デバッグ用

  const fastExtractToggle = document.getElementById("fastExtractToggle");

  if (!fastExtractToggle) {
      console.error("fastExtractToggle要素が見つかりません。HTMLにid='fastExtractToggle'が設定されているか確認してください。");
      return;
  }

  // 初期状態を反映
  chrome.storage.local.get("fastExtract", (data) => {
      if (chrome.runtime.lastError) {
          console.error("chrome.storage.local.getでエラーが発生:", chrome.runtime.lastError);
          return;
      }

      const isFastExtractEnabled = !!data.fastExtract; // デフォルト値はfalse
      fastExtractToggle.checked = isFastExtractEnabled;
      console.log(`高速抽出初期状態: ${isFastExtractEnabled ? "ON" : "OFF"}`);
  });

  // トグルが変更されたときの処理
  fastExtractToggle.addEventListener("change", (event) => {
      const isFastExtractOn = event.target.checked;

      chrome.storage.local.set({ fastExtract: isFastExtractOn }, () => {
          if (chrome.runtime.lastError) {
              console.error("chrome.storage.local.setでエラーが発生:", chrome.runtime.lastError);
              return;
          }

          console.log(`高速抽出の状態が保存されました: ${isFastExtractOn ? "ON" : "OFF"}`);
      });
  });
});

