document.addEventListener("DOMContentLoaded", () => {
    // 必要な要素を取得
    const selectAllCheckbox = document.getElementById("selectAll");
    const dataTable = document.getElementById("dataTable");

    // ライセンス情報をロード
    loadLicenseInfo();

    // NG設定をロード（デフォルト値を含む）
    loadNGSettings();

    // データをロード（未出品データ）
    loadData();

    // イベントリスナーの設定
    document.getElementById("verifyLicense").addEventListener("click", verifyLicense);
    document.getElementById("saveSettings").addEventListener("click", saveNGSettings);
    document.getElementById("exportSelectedCSV").addEventListener("click", exportSelectedToCSV);
    document.getElementById("exportAllCSV").addEventListener("click", exportAllToCSV);

    // SKU検索用のボタンにイベントを追加
    document.getElementById("searchSKUButton").addEventListener("click", () => {
        const filterSKU = document.getElementById("searchSKUInput").value.trim();
        loadExportedData(filterSKU); // SKUフィルタを利用して出品済みデータをロード
    });

    // 全選択/全解除チェックボックスのイベント設定
    selectAllCheckbox.addEventListener("change", () => {
        const isChecked = selectAllCheckbox.checked;
        const checkboxes = dataTable.querySelectorAll("tbody input[type='checkbox']");
        checkboxes.forEach((checkbox) => {
            checkbox.checked = isChecked;
        });
    });

    // 個別チェックボックスの状態に応じて全選択チェックボックスを更新
    dataTable.addEventListener("change", (event) => {
        if (event.target.type === "checkbox") {
            const checkboxes = dataTable.querySelectorAll("tbody input[type='checkbox']");
            const allChecked = Array.from(checkboxes).every((checkbox) => checkbox.checked);
            const noneChecked = Array.from(checkboxes).every((checkbox) => !checkbox.checked);

            selectAllCheckbox.checked = allChecked; // 全選択された場合はチェック
            selectAllCheckbox.indeterminate = !allChecked && !noneChecked; // 一部選択の場合は中間状態
        }
    });

    console.log("DOMContentLoadedイベントが発火しました - data_manager.js");

    const fastExtractToggle = document.getElementById("fastExtractToggle");

    if (!fastExtractToggle) {
        console.error("fastExtractToggle要素が見つかりません。HTMLを確認してください。");
        return;
    }

    // 初期状態を反映
    chrome.storage.local.get("fastExtract", (data) => {
        if (chrome.runtime.lastError) {
            console.error("chrome.storage.local.getでエラーが発生しました:", chrome.runtime.lastError);
            return;
        }

        const isFastExtractEnabled = !!data.fastExtract; // デフォルト値はfalse
        fastExtractToggle.checked = isFastExtractEnabled;
        console.log(`高速抽出初期状態: ${isFastExtractEnabled ? "ON" : "OFF"}`);
    });

    // トグルが変更されたときの処理
    fastExtractToggle.addEventListener("change", (event) => {
        const isFastExtractOn = event.target.checked;

        chrome.storage.local.set({ fastExtract: isFastExtractOn }, () => {
            if (chrome.runtime.lastError) {
                console.error("chrome.storage.local.setでエラーが発生しました:", chrome.runtime.lastError);
                return;
            }

            console.log(`高速抽出の状態が保存されました: ${isFastExtractOn ? "ON" : "OFF"}`);
        });
    });

});

function loadNGSettings() {
    // デフォルト値を読み込む
    const defaultNGUsers = ["exampleUser1", "exampleUser2"]; // 初期設定のNGユーザー
    const defaultNGWords = ["exampleWord1", "exampleWord2"]; // 初期設定のNGワード

    chrome.storage.local.get(["ngUsers", "ngWords"], (data) => {
        let ngUsers = data.ngUsers || defaultNGUsers; // ストレージに値がない場合はデフォルト値
        let ngWords = data.ngWords || defaultNGWords;

        // テキストエリアに値をセット
        document.getElementById("ng-users").value = ngUsers.join("\n");
        document.getElementById("ng-words").value = ngWords.join("\n");

        // 初回のみストレージにデフォルト値を保存
        if (!data.ngUsers || !data.ngWords) {
            chrome.storage.local.set({ ngUsers, ngWords });
        }
    });
}

function saveNGSettings() {
    // テキストエリアから値を取得
    const ngUsers = document.getElementById("ng-users").value.split("\n").filter(Boolean);
    const ngWords = document.getElementById("ng-words").value.split("\n").filter(Boolean);

    // ストレージに保存
    chrome.storage.local.set({ ngUsers, ngWords }, () => {
        alert("設定が保存されました！");
    });
}

function loadLicenseInfo() {
    // ストレージからライセンス情報を取得
    chrome.storage.local.get(["username", "licenseKey"], (data) => {
        if (data.username) document.getElementById("username").value = data.username;
        if (data.licenseKey) document.getElementById("licenseKey").value = data.licenseKey;
    });
}

function verifyLicense() {
    // 入力値を取得
    const username = document.getElementById("username").value;
    const licenseKey = document.getElementById("licenseKey").value;

    if (!username || !licenseKey) {
        alert("ユーザー名とライセンスコードを入力してください。");
        return;
    }

    // メッセージをバックグラウンドスクリプトに送信してライセンスを確認
    chrome.runtime.sendMessage({ action: "verifyLicense", username, licenseKey }, (response) => {
        if (response.success) {
            alert("ライセンスが有効です。");
        } else {
            alert("ライセンスが無効です。");
        }
    });
}

function loadData() {
    chrome.storage.local.get("scrapedData", (result) => {
        const data = result.scrapedData || [];
        const tbody = document.querySelector("#dataTable tbody");
        tbody.innerHTML = ""; // テーブルをリセット

        data.forEach((item, index) => {
            if (item.isExported) return; // 出品済みデータはスキップ

            const row = document.createElement("tr");

            // チェックボックス列
            const selectCell = document.createElement("td");
            const checkbox = document.createElement("input");
            checkbox.type = "checkbox";
            checkbox.value = index;
            selectCell.appendChild(checkbox);
            row.appendChild(selectCell);

            // 写真列
            const imageCell = document.createElement("td");
            const imageWrapper = document.createElement("div");
            imageWrapper.style.display = "grid";
            imageWrapper.style.gridTemplateColumns = "repeat(5, 1fr)";
            imageWrapper.style.gap = "5px";

            const imageUrls = [
                item["画像URL1"], item["画像URL2"], item["画像URL3"],
                item["画像URL4"], item["画像URL5"], item["画像URL6"],
                item["画像URL7"], item["画像URL8"], item["画像URL9"], item["画像URL10"]
            ];

            imageUrls.forEach((url) => {
                if (url) {
                    const img = document.createElement("img");
                    img.src = url;
                    img.alt = "商品画像";
                    img.style.width = "50px";
                    img.style.height = "50px";
                    img.style.objectFit = "cover";
                    img.style.border = "1px solid #ccc";
                    imageWrapper.appendChild(img);
                }
            });

            imageCell.appendChild(imageWrapper);
            row.appendChild(imageCell);

            // 購入先列
            const sellerCell = document.createElement("td");
            sellerCell.textContent = item["ユーザー名"] || "未設定";
            row.appendChild(sellerCell);

            // 商品名列（リンク付き）
            const nameCell = document.createElement("td");
            const nameLink = document.createElement("a");
            nameLink.href = item["URL"];
            nameLink.textContent = item["商品名"] || "商品名未設定";
            nameLink.target = "_blank";
            nameCell.appendChild(nameLink);
            row.appendChild(nameCell);

            // 商品金額列
            const priceCell = document.createElement("td");
            priceCell.textContent = item["商品金額"] || "未設定";
            row.appendChild(priceCell);

            tbody.appendChild(row);
        });
    });
}

function loadExportedData(filterSKU = "") {
    chrome.storage.local.get("scrapedData", (result) => {
        const data = result.scrapedData || [];
        const tbody = document.querySelector("#exportedDataTable tbody");
        tbody.innerHTML = ""; // テーブルをリセット

        data.forEach((item) => {
            if (!item.isExported) return; // 出品済みデータのみ対象

            const skuMatch = item.URL && item.URL.match(/item\/([^\/?]+)/);
            const sku = skuMatch ? skuMatch[1] : "N/A";

            if (filterSKU && !sku.includes(filterSKU)) return; // SKUフィルタリング

            const row = document.createElement("tr");

            // SKU列
            const skuCell = document.createElement("td");
            skuCell.textContent = sku;
            row.appendChild(skuCell);

            // 写真列
            const imageCell = document.createElement("td");
            const imageWrapper = document.createElement("div");
            imageWrapper.style.display = "grid";
            imageWrapper.style.gridTemplateColumns = "repeat(5, 1fr)";
            imageWrapper.style.gap = "5px";

            const imageUrls = [
                item["画像URL1"], item["画像URL2"], item["画像URL3"],
                item["画像URL4"], item["画像URL5"], item["画像URL6"],
                item["画像URL7"], item["画像URL8"], item["画像URL9"], item["画像URL10"]
            ];

            imageUrls.forEach((url) => {
                if (url) {
                    const img = document.createElement("img");
                    img.src = url;
                    img.alt = "商品画像";
                    img.style.width = "50px";
                    img.style.height = "50px";
                    img.style.objectFit = "cover";
                    img.style.border = "1px solid #ccc";
                    imageWrapper.appendChild(img);
                }
            });

            imageCell.appendChild(imageWrapper);
            row.appendChild(imageCell);

            // 購入先列
            const sellerCell = document.createElement("td");
            sellerCell.textContent = item["ユーザー名"] || "未設定";
            row.appendChild(sellerCell);

            // 商品名列（リンク付き）
            const nameCell = document.createElement("td");
            const nameLink = document.createElement("a");
            nameLink.href = item["URL"];
            nameLink.textContent = item["商品名"] || "商品名未設定";
            nameLink.target = "_blank";
            nameCell.appendChild(nameLink);
            row.appendChild(nameCell);

            // 商品金額列
            const priceCell = document.createElement("td");
            priceCell.textContent = item["商品金額"] || "未設定";
            row.appendChild(priceCell);

            tbody.appendChild(row);
        });
    });
}

// CSVエクスポートのための関数
function saveToCSV(dataList) {
    const csvHeader = [
        "商品名", "商品金額", "商品説明", "商品URL", "ユーザー名",
        "カテゴリー", "商品の状態", "配送料の負担", "配送の方法",
        "発送元の地域", "発送までの日数", "画像URL1", "画像URL2",
        "画像URL3", "画像URL4", "画像URL5", "画像URL6",
        "画像URL7", "画像URL8", "画像URL9", "画像URL10"
    ];

    const csvRows = [];
    csvRows.push(csvHeader.join(",")); // ヘッダー行

    dataList.forEach((data) => {
        const row = csvHeader.map((key) => {
            let value = data[key] || ""; // キーに基づいて値を取得
            if (key === "商品URL") value = data["URL"] || ""; // 商品URLを特別にマッピング
            return `"${value.replace(/"/g, '""')}"`; // ダブルクォートをエスケープ
        }).join(",");
        csvRows.push(row);
    });

    const csvString = csvRows.join("\n");
    const blob = new Blob([csvString], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);

    const a = document.createElement("a");
    a.href = url;
    a.download = `exported_data.csv`; // ダウンロードするファイル名
    a.click();
}

// 選択されたデータをCSVでエクスポート
function exportSelectedToCSV() {
    chrome.storage.local.get("scrapedData", (result) => {
        const data = result.scrapedData || [];
        const selectedIndexes = Array.from(
            document.querySelectorAll("#dataTable tbody input[type='checkbox']:checked")
        ).map((checkbox) => parseInt(checkbox.value));
        const selectedData = selectedIndexes.map(index => data[index]);

        saveToCSV(selectedData); // 選択データをエクスポート

        // エクスポート済みフラグを設定
        selectedIndexes.forEach(index => {
            data[index].isExported = true;
        });

        // データをストレージに保存
        chrome.storage.local.set({ scrapedData: data }, () => {
            loadData(); // 再ロードしてUIを更新
        });
    });
}

// すべての未出品データをCSVでエクスポート
function exportAllToCSV() {
    chrome.storage.local.get("scrapedData", (result) => {
        const data = result.scrapedData || [];

        // 未出品フラグが付いている商品だけをフィルタリング
        const unexportedData = data.filter(item => !item.isExported);

        if (unexportedData.length === 0) {
            alert("未出品のデータがありません。");
            return;
        }

        // フィルタリングされたデータをCSVとして保存
        saveToCSV(unexportedData);

        // エクスポート済みフラグを設定
        unexportedData.forEach(item => {
            item.isExported = true; // フラグを設定
        });

        // 更新されたデータをストレージに保存
        chrome.storage.local.set({ scrapedData: data }, () => {
            loadData(); // テーブルを再ロードしてUIを更新
        });
    });
}


// テーブルをフィルタリング
function filterTable() {
    const filter = document.getElementById("searchInput").value.toLowerCase(); // 検索条件
    const rows = document.querySelectorAll("#dataTable tbody tr");
    rows.forEach((row) => {
        const nameCell = row.cells[3].textContent.toLowerCase(); // 商品名列
        row.style.display = nameCell.includes(filter) ? "" : "none"; // 条件に一致しない行を非表示
    });
}

// タブ切り替え時にデータをロード
document.querySelector("#dataManagerTabs").addEventListener("click", (event) => {
    if (event.target.id === "data-tab") {
        loadData(); // 未出品データをロード
    } else if (event.target.id === "exported-data-tab") {
        loadExportedData(); // 出品済みデータをロード
    }
});
