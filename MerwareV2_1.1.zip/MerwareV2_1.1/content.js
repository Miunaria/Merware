// NGワードラベル付け機能
chrome.storage.local.get(["ngWords"], (data) => {
    const NG_WORDS = data.ngWords || ["偽物", "コピー", "詐欺"]; // デフォルトのNGワード

    function processItems() {
        const items = document.querySelectorAll("#item-grid > ul > li");
        items.forEach((item) => {
            const itemText = item.textContent?.trim();
            if (!itemText) return;

            if (NG_WORDS.some((word) => itemText.includes(word))) {
                if (!item.querySelector(".ng-label")) {
                    const label = document.createElement("div");
                    label.className = "ng-label";
                    label.innerText = "⚠️ NGワード ⚠️";
                    label.style.cssText = `
                        position: absolute;
                        top: 5px;
                        left: 5px;
                        background-color: #ff0000;
                        color: white;
                        padding: 10px;
                        border-radius: 8px;
                        font-size: 16px;
                        font-weight: bold;
                    `;
                    item.style.position = "relative";
                    item.appendChild(label);
                }
            }
        });
    }

    const observer = new MutationObserver(() => {
        processItems();
    });
    observer.observe(document.body, { childList: true, subtree: true });

    document.addEventListener("DOMContentLoaded", () => {
        processItems();
    });
});

// 商品データ抽出機能
async function scrapeItemDetails() {
    const data = {
        "商品名": "",
        "商品金額": "",
        "商品説明": "",
        "URL": "",
        "ユーザー名": "",
        "カテゴリー": "",
        "商品の状態": "",
        "配送料の負担": "",
        "配送の方法": "",
        "発送元の地域": "",
        "発送までの日数": "",
        "画像URL1": "",
        "画像URL2": "",
        "画像URL3": "",
        "画像URL4": "",
        "画像URL5": "",
        "画像URL6": "",
        "画像URL7": "",
        "画像URL8": "",
        "画像URL9": "",
        "画像URL10": ""
    };

    try {
        // 基本情報の取得
        data["商品名"] = document.querySelector("#item-info > section:nth-child(1) > div > div > div > h1")?.innerText.trim() || "";
        data["商品金額"] = document.querySelector("#item-info section:nth-child(2) div div div")?.innerText.trim() || "";
        data["商品説明"] = document.querySelector("#item-info .merShowMore pre")?.innerText.trim() || "";
        data["URL"] = window.location.href;
        data["ユーザー名"] = document.querySelector("#item-info > section:nth-child(5) > div > a > div > div > div > p")?.innerText.trim() || "";

        // 詳細情報の取得
        const parentElement = document.querySelector("#item-info > section.sc-1a095b48-7.dbKLOC");
        if (parentElement) {
            //const childElements = parentElement.querySelectorAll("div.個々を変更（sc-a87ca833-0.hlkSoF）の部分 > div");
            const childElements = parentElement.querySelectorAll("div.sc-a87ca833-0.hlkSoF > div");
            childElements.forEach((child) => {
                const text = child.innerText.trim();

                if (text.includes("カテゴリー")) {
                    data["カテゴリー"] = text.replace("カテゴリー", "").trim();
                } else if (text.includes("商品の状態")) {
                    data["商品の状態"] = text.replace("商品の状態", "").trim();
                } else if (text.includes("配送料の負担")) {
                    data["配送料の負担"] = text.replace("配送料の負担", "").trim();
                } else if (text.includes("配送の方法")) {
                    data["配送の方法"] = text.replace("配送の方法", "").trim();
                } else if (text.includes("発送元の地域")) {
                    data["発送元の地域"] = text.replace("発送元の地域", "").trim();
                } else if (text.includes("発送までの日数")) {
                    data["発送までの日数"] = text.replace("発送までの日数", "").trim();
                }
            });
        }

        // 商品IDを抽出
        const itemId = getItemIdFromURL(data["URL"]);
        if (!itemId) {
            alert("商品IDを取得できませんでした。");
            return;
        }

        // 画像URLを取得
        const imageUrls = await getImageUrls(itemId);
        imageUrls.forEach((url, index) => {
            if (index < 10) {
                data[`画像URL${index + 1}`] = url;
            }
        });

        // データをローカルに保存
        saveToLocalStorage(data);
        // 必要に応じてタブを閉じる
        setTimeout(() => window.close(), 500);
    } catch (error) {
        console.error("商品データ抽出中にエラーが発生しました:", error);
        alert("商品データの抽出中にエラーが発生しました。詳細はコンソールを確認してください。");
    }
}

function saveToLocalStorage(data) {
    chrome.storage.local.get("scrapedData", (result) => {
        const existingData = result.scrapedData || [];
        const isDuplicate = existingData.some((item) => item.URL === data.URL);

        if (!isDuplicate) {
            existingData.push(data);
            chrome.storage.local.set({ scrapedData: existingData }, () => {
                console.log("データが保存されました:", data);
            });
        } else {
            console.log("既に同じURLの商品データが存在します:", data.URL);
        }
    });
}

// URLから商品IDを取得する関数
function getItemIdFromURL(url) {
    const match = url.match(/https:\/\/jp\.mercari\.com\/item\/([a-zA-Z0-9]+)/);
    return match ? match[1] : null;
}

// 画像URLを取得する関数
async function getImageUrls(itemId) {
    const baseImageUrl = "https://static.mercdn.net/item/detail/orig/photos/";
    const imageUrls = [];

    for (let i = 1; i <= 10; i++) {
        const imageUrl = `${baseImageUrl}${itemId}_${i}.jpg`;
        const isValid = await checkImageValid(imageUrl);
        if (isValid) {
            imageUrls.push(imageUrl);
        }
    }

    return imageUrls;
}

// 画像URLが有効かをチェックする関数
function checkImageValid(url) {
    return new Promise((resolve) => {
        const img = new Image();
        img.onload = () => resolve(true);
        img.onerror = () => resolve(false);
        img.src = url;
    });
}

// CSVを保存する機能
function saveToCSV(data) {
    const csvHeader = [
        "商品名", "商品金額", "商品説明", "URL", "ユーザー名",
        "カテゴリー", "商品の状態", "配送料の負担", "配送の方法",
        "発送元の地域", "発送までの日数", "画像URL1", "画像URL2", "画像URL3", 
        "画像URL4", "画像URL5", "画像URL6", "画像URL7", "画像URL8", "画像URL9", "画像URL10"
    ];

    const csvRows = [];
    csvRows.push(csvHeader.join(",")); // ヘッダー行
    csvRows.push(csvHeader.map((key) => {
        const value = data[key] || ""; 
        return `"${value.replace(/"/g, '""')}"`; 
    }).join(",")); 

    const csvString = csvRows.join("\n");
    const blob = new Blob([csvString], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);

    const a = document.createElement("a");
    a.href = url;
    a.download = `${data["商品名"]}.csv`;
    a.click();
}

// 抽出ボタンをページに追加
function addExtractButton() {
    const referenceElement = document.querySelector("#item-info > section:nth-child(1) > section:nth-child(2) > div > div > p");
    if (!referenceElement) return;

    if (document.querySelector("#extract-button")) return;

    const button = document.createElement("button");
    button.id = "extract-button";
    button.innerText = "抽出開始";
    button.style.cssText = `
        margin-left: 15px;
        padding: 10px 20px;
        background-color: #28a745;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 14px;
    `;
    button.addEventListener("click", () => scrapeItemDetails());
    referenceElement.parentElement.appendChild(button);

    // 初期状態でNGユーザーステータスを更新
    const userName = document.querySelector("#item-info > section:nth-child(5) > div > a > div > div > div > p")?.innerText.trim() || "";
    updateNGUserStatus(userName);
}
function getUserNameWithRetry(retryCount = 5) {
    const userNameElement = document.querySelector("#item-info > section:nth-child(5) > div > a > div > div > div > p");
    if (userNameElement) {
        const userName = userNameElement.innerText.trim();
        updateNGUserStatus(userName); // 取得成功時にNGユーザー判定処理を呼び出し
        return;
    } else if (retryCount > 0) {
        setTimeout(() => getUserNameWithRetry(retryCount - 1), 500); // 0.5秒後にリトライ
    } else {
        console.error("ユーザー名を取得できませんでした。");
    }
}

// 初期化のタイミングでリトライを実行
document.addEventListener("DOMContentLoaded", () => {
    getUserNameWithRetry();
});

function updateNGUserStatus(userName) {
    let statusElement = document.querySelector("#ng-user-status");

    // ステータス要素が存在しない場合、新規作成
    if (!statusElement) {
        statusElement = document.createElement("span");
        statusElement.id = "ng-user-status";
        statusElement.style.cssText = `
            margin-left: 10px;
            font-size: 14px;
            font-weight: bold;
        `;
        const extractButton = document.querySelector("#extract-button");
        if (extractButton) {
            extractButton.parentElement.appendChild(statusElement);
        }
    }

    // NGユーザーリストを確認して内容を更新
    chrome.storage.local.get(["ngUsers"], (data) => {
        const ngUsers = (data.ngUsers || []).map((user) => user.trim());
        if (ngUsers.includes(userName.trim())) {
            statusElement.innerText = "NGユーザー";
            statusElement.style.color = "red";
        } else {
            statusElement.innerText = "NG登録されていません";
            statusElement.style.color = "green";
        }
    });
}

const targetNode = document.querySelector("#item-info");
if (targetNode) {
    observer.observe(targetNode, { childList: true, subtree: true });
}

// 定期的にNGユーザーステータスを更新
function initializeNGUserStatus() {
    const updateStatusOnLoadAndChange = () => {
        const userName = document.querySelector("#item-info > section:nth-child(5) > div > a > div > div > div > p")?.innerText.trim() || "";
        if (userName) {
            updateNGUserStatus(userName);
        }
    };

    
    // ページロード時に実行
    document.addEventListener("DOMContentLoaded", updateStatusOnLoadAndChange);

    // DOMの変更を監視して実行
    const observer = new MutationObserver(() => {
       updateStatusOnLoadAndChange();
    });

    const targetNode = document.body;
   observer.observe(targetNode, { childList: true, subtree: true });
}

// 初期化
initializeNGUserStatus();

//shopの場合
function closeTabIfShopsInURL() {
    if (window.location.href.includes("shops")) {
        setTimeout(() => {
            window.close();
        }, 500); // 1秒後にタブを閉じる
    }
}

// ページロード時にURLをチェックしてタブを閉じる
//document.addEventListener("DOMContentLoaded", () => {
//    closeTabIfShopsInURL();
//});

// ページの監視とボタン追加
const observer = new MutationObserver(() => {
    addExtractButton();
    //startNGUserStatusUpdate(); // ページ変化後も定期更新を確保
});
observer.observe(document.body, { childList: true, subtree: true });

document.addEventListener("DOMContentLoaded", () => {
    addExtractButton();
    //monitorNGUserStatus(); // NGユーザーの監視を追加
    //startNGUserStatusUpdate(); // 初期状態でNGユーザー更新を開始
});

// ライセンスが無効な場合機能を無効化
chrome.storage.local.get("licenseStatus", (data) => {
    if (data.licenseStatus !== "valid") {
        alert("ライセンスが無効です。この拡張機能を使用するには有効なライセンスが必要です。");
        document.body.innerHTML = "<h1>ライセンスが必要です</h1>";
    } else {
        console.log("ライセンスが有効です。機能を実行します。");
        // 通常の機能をここで初期化
    }
});

// 商品ページかどうかを判定する関数
function isProductPage() {
    return /https:\/\/jp\.mercari\.com\/item\//.test(window.location.href);
}

// 商品ページでかつ高速抽出が有効な場合に実行
chrome.storage.local.get("fastExtract", (data) => {
    const isFastExtractEnabled = data.fastExtract || false; // デフォルト値はfalse
    if (isFastExtractEnabled && isProductPage()) {
        console.log("高速抽出が有効です。自動抽出を開始します...");
         // この下のコメント解除で高速抽出が有効になる
        scrapeItemDetailsWithAlert();
    } else {
        console.log(`高速抽出の状態: ${isFastExtractEnabled ? "ON" : "OFF"}`);
        console.log("自動抽出は実行されません。");
    }
});

// scrapeItemDetails()関数のラッパーでアラートを追加
function scrapeItemDetailsWithAlert() {
    const delay = 2000; // 待機時間（ミリ秒）

    // ページが完全にロードされたことを確認
    window.addEventListener("load", () => {
        console.log("ページが完全にロードされました。抽出を開始します...");

        setTimeout(() => {
            scrapeItemDetails().then(() => {
                console.log("抽出が完了しました。");
                //setTimeout(() => window.close(), 1000); // 必要に応じてタブを閉じる
            }).catch((error) => {
                console.error("抽出中にエラーが発生しました:", error);
            });
        }, delay);
    });
}


