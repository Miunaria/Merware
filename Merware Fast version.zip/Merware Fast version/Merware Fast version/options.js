document.addEventListener("DOMContentLoaded", () => {

// 前回保存された情報をフォームに復元
chrome.storage.local.get(["username", "licenseKey"], (data) => {
    if (data.username) {
        document.getElementById("username").value = data.username;
    }
    if (data.licenseKey) {
        document.getElementById("licenseKey").value = data.licenseKey;
    }
    document.getElementById("verifyLicense").click();
});


    document.getElementById("verifyLicense").addEventListener("click", () => {
        const username = document.getElementById("username").value;
        const licenseKey = document.getElementById("licenseKey").value;

        if (!username || !licenseKey) {
            document.getElementById("statusMessage").textContent = "ユーザー名とライセンスコードを入力してください。";
            return;
        }

        chrome.runtime.sendMessage(
            { action: "verifyLicense", username, licenseKey },
            (response) => {
                if (response.success) {
                    document.getElementById("statusMessage").textContent = "ライセンスが有効です。";
                } else {
                    document.getElementById("statusMessage").textContent = "ライセンスが無効です。";
                }
            }
        );
    });
});



document.addEventListener("DOMContentLoaded", () => {
    const ngWordsArea = document.getElementById("ng-words");
    const ngUsersArea = document.getElementById("ng-users");
    const saveButton = document.getElementById("save");
    const addCurrentUserButton = document.getElementById("add-current-user");

    // 設定をロード
    chrome.storage.local.get(["ngWords", "ngUsers"], (data) => {
        ngWordsArea.value = (data.ngWords || []).join("\n");
        ngUsersArea.value = (data.ngUsers || []).join("\n");
    });

    // 設定を保存
    saveButton.addEventListener("click", () => {
        const ngWords = ngWordsArea.value.split("\n").map((word) => word.trim()).filter((word) => word);
        const ngUsers = ngUsersArea.value.split("\n").map((user) => user.trim()).filter((user) => user);

        chrome.storage.local.set({ ngWords, ngUsers }, () => {
            alert("設定が保存されました");
        });
    });

    // 現在の商品ページのユーザーをNGユーザーに追加
    addCurrentUserButton.addEventListener("click", () => {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            const activeTab = tabs[0];
            if (!activeTab || !activeTab.url.includes("https://jp.mercari.com/item/")) {
                alert("現在のタブはMercariの商品ページではありません。");
                return;
            }

            // コンテンツスクリプトにユーザー名取得を依頼
            chrome.scripting.executeScript(
                {
                    target: { tabId: activeTab.id },
                    func: () => {
                        return document.querySelector("#item-info > section:nth-child(5) > div > a > div > div > div > p")?.innerText.trim() || null;
                    },
                },
                (results) => {
                    const userName = results[0]?.result;
                    if (!userName) {
                        alert("ユーザー名を取得できませんでした。");
                        return;
                    }

                    // NGユーザーリストに追加
                    chrome.storage.local.get(["ngUsers"], (data) => {
                        const ngUsers = data.ngUsers || [];
                        if (!ngUsers.includes(userName)) {
                            ngUsers.push(userName);
                            chrome.storage.local.set({ ngUsers }, () => {
                                alert(`「${userName}」をNGユーザーに追加しました。`);
                                ngUsersArea.value = ngUsers.join("\n");
                            });
                        } else {
                            alert(`「${userName}」はすでにNGユーザーです。`);
                        }
                    });
                }
            );
        });
    });
});
