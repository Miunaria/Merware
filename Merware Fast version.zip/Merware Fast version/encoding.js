function saveToCSV(data) {
    const csvHeader = [
        "商品名", "商品金額", "商品説明", "URL", "ユーザー名",
        "カテゴリー", "商品のサイズ", "ブランド", "商品の状態",
        "配送料の負担", "配送の方法", "発送元の地域", "発送までの日数"
    ];

    const csvRows = [
        csvHeader.join(","), // ヘッダー行
        csvHeader.map((key) => `"${(data[key] || "").replace(/¥/g, "￥")}"`).join(",") // データ行
    ];

    const csvContent = csvRows.join("\n");
    console.log("生成されたCSVデータ:", csvContent);

    // Shift-JIS に変換
    try {
        const sjisArray = Encoding.convert(Encoding.stringToCode(csvContent), "SJIS");
        const blob = new Blob([new Uint8Array(sjisArray)], { type: "text/csv;charset=shift_jis;" });

        const itemId = data.URL.split("/item/")[1] || "unknown";
        const filename = `${itemId}.csv`;

        const url = URL.createObjectURL(blob);
        console.log("ダウンロード用URL:", url);

        // ダウンロードリクエストを送信
        chrome.runtime.sendMessage(
            { action: "downloadCSV", url, filename },
            (response) => {
                if (response && response.success) {
                    console.log("CSV保存成功:", filename);
                    alert("CSVファイルが正常に保存されました！");
                } else {
                    console.error("ダウンロードエラー:", response.error || "不明なエラー");
                    alert("CSV保存時にエラーが発生しました。詳細はコンソールを確認してください。");
                }
            }
        );
    } catch (error) {
        console.error("Shift-JIS変換中にエラーが発生しました:", error);
        alert("CSV保存処理中に予期しないエラーが発生しました。詳細はコンソールを確認してください。");
    }
}
